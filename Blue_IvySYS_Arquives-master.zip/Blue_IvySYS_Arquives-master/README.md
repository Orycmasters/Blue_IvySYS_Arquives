﻿# Blue_IvySYS_Arquives
Projeto de sistema online para lojas

===========================================================================
INSTITUTO FEDERAL DE EDUCAÇÃO E TECNOLOGIA DO RIO GRANDE DO NORTE - IFRN

CAMPUS JOÃO CÂMARA

CURSO TÉCNICO EM INFORMÁTICA

DISCIPLINA: Programação para Internet com Acesso a Banco de Dados

COLABORADORES:

Cyro Andreolle L Soares, 
Jaianderson Santos, 
Liara de Paula, 
Maria Karoline, 
Marijane Lucindo.
___________________________________________________________________________

Project Development

Software name: Blue Ivy

Basic Description

O projeto consiste em um sistema de gerenciamento de produtos para lojas online.
A IDE utilizada pelos colaboradores para o desenvolvimento do código é o NetBeans.
A linguagem de programação é o Java Versão 7.x.
A IDE para desenvolvimento do Banco de Dados é o MySQL. Utilizamos o MySQLWorkbench como software de 
auxílio na criação do Modelo Físico do BD.

OBS.: Este arquivo é passível de modificações.

