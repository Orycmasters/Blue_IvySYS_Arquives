# Blue_IvySYS_Arquives
Projeto de sistema online para lojas

=================================================================================================================

O diagrama de entidade relacionamento já foi adicionado. Ele tá ai pra a gnt ir dando continuidade nele, aos
poucos.. por favor.. continuem ele. Vow estar no GitHub TODOS OS DIAS, e vow ver as modificações feitas,
e quem as fez.. 

OBSERVAÇÕES SOBRE O DIAGRAMA

Utilizem o BRModelo pra abrir o arquivo e executar as modificações.
Lembrem que o prazo máximo estipulado pelo cronograma é até a próxima quarta-feira (dia 28 de Janeiro).
Portanto, é recomendado que seja concluido bem antes, para que possam ser resolvidos possiveis problemas até 
a data de entrega. 



OBS.: Não creio que seja necessário falar algo sobre como utilizar o GitHub, pois já houve até prova sobre o
assunto.. lembrem de dar pull request, para que eu possa aceitar as modificações efetuadas por vcs.

_______________________________________
Cyro Andreolle L Soares
